#include <Arduino.h>

#include <ArduinoJson.h>
#include "PubSubClient.h"
#include <WiFi.h>
#include <WiFiManager.h>
#include "WiFiClientSecure.h"
#include <HTTPClient.h>
#include <HTTPUpdate.h>
#include "cert.h"
#include <Update.h>
#include <Wire.h>
#include <ArduinoOTA.h>
#include "time.h"
#include "cert.h"

//#include "soc/soc.h"
//#include "soc/rtc_cntl_reg.h"

String FirmwareVer = "0.0.0";

#define URL_fw_Version "https://raw.githubusercontent.com/greenioiot/Smart_Pier/main/SET2_ULTRASONIC/bin_version.txt"

#define URL_fw_Bin "https://raw.githubusercontent.com/greenioiot/Smart_Pier/main/SET2_ULTRASONIC/firmware.bin"




#define battPIN  34
#define donePIN  25

int contentLength = 0;
bool isValidContentType = false;

String deviceToken = "";


String bin = "greenioiot/Smart_Pier/main/Smart_Pier.ino.bin"; // bin file name with a slash in front.
String vers = "/api/v1/" + deviceToken + "/attributes?clientKeys=version"; // bin file name with a slash in front.


int ver_compare = 0;

char thingsboardServer[] = "mqtt.thingcontrol.io";

String json = "";

unsigned long startMillis;  //some global variables available anywhere in the program
unsigned long startTeleMillis;
unsigned long starSendTeletMillis, ReadDistance_TIME;
unsigned long currentMillis;
unsigned long dayMillis;
const unsigned long periodSendTelemetry = 60 * 1000,periodReadDistance_TIME = 5 * 1000;//the value is a number of millisecond

  

// circular Distance DATA
const int DistanceBufferLength = 10;
int DistanceBuffer[DistanceBufferLength];
int DistanceBufferIndex = 0;


//NTP Server
const char* ntpServer = "pool.ntp.org";
const long  gmtOffset_sec = 7 * 60 * 60;
const int   daylightOffset_sec = 3600;
struct tm timeinfo;

//WiFi&OTA 参数
String HOSTNAME = "";
#define PASSWORD "green7650" //the password for OTA upgrade, can set it in any char you want
char WIFINAME[50] ;

WiFiClientSecure wifiClient;
PubSubClient client(wifiClient);

int status = WL_IDLE_STATUS;
int PORT = 8883;


void firmwareUpdate();

int FirmwareVersionCheck(void)
{
  String payload;
  int httpCode;
  String fwurl = "";
  fwurl += URL_fw_Version;
  fwurl += "?";
  fwurl += String(rand());
  Serial.println(fwurl);
  WiFiClientSecure *client = new WiFiClientSecure;

  if (client)
  {
    client->setCACert(rootCACertificate);

    // Add a scoping block for HTTPClient https to make sure it is destroyed before WiFiClientSecure *client is
    HTTPClient https;

    if (https.begin(*client, fwurl))
    { // HTTPS
      Serial.print("[HTTPS] GET...\n");
      // start connection and send HTTP header
      delay(100);
      httpCode = https.GET();
      delay(100);
      if (httpCode == HTTP_CODE_OK) // if version received
      {
        payload = https.getString(); // save received version
      }
      else
      {
        Serial.print("error in downloading version file:");
        Serial.println(httpCode);
      }
      https.end();
    }
    delete client;
  }

  if (httpCode == HTTP_CODE_OK) // if version received
  {
    payload.trim();
    if (payload.equals(FirmwareVer))
    {
      Serial.printf("\nDevice already on latest firmware version:%s\n", FirmwareVer);
      return 0;
    }
    else
    {
      Serial.println(payload);
      Serial.println("New firmware detected");
      return 1;
    }
  }
  return 0;
}

void firmwareUpdate(void)
{
  WiFiClientSecure client;
  client.setCACert(rootCACertificate);
  t_httpUpdate_return ret = httpUpdate.update(client, URL_fw_Bin);

  switch (ret)
  {
  case HTTP_UPDATE_FAILED:
    Serial.printf("HTTP_UPDATE_FAILD Error (%d): %s\n", httpUpdate.getLastError(), httpUpdate.getLastErrorString().c_str());
    break;

  case HTTP_UPDATE_NO_UPDATES:
    Serial.println("HTTP_UPDATE_NO_UPDATES");
    break;

  case HTTP_UPDATE_OK:
    Serial.println("HTTP_UPDATE_OK");
    break;
  }
}

void OTA_git_CALL()
{
  if (FirmwareVersionCheck())
  {
    firmwareUpdate();
  }
}

void configModeCallback (WiFiManager *myWiFiManager) {
  Serial.println("Entered config mode");
  Serial.println(WiFi.softAPIP());
  //if you used auto generated SSID, print it
  Serial.println(myWiFiManager->getConfigPortalSSID());
}

uint64_t espChipID = ESP.getEfuseMac();

String mac2String(byte ar[]) {
  String s;
  for (byte i = 0; i < 6; ++i)
  {
    char buf[3];
    sprintf(buf, "%02X", ar[i]); // J-M-L: slight modification, added the 0 in the format for padding
    s += buf;
    if (i < 5) s += ':';
  }
  return s;
}

String getHeaderValue(String header, String headerName) {
  return header.substring(strlen(headerName.c_str()));
}


int distan;
//struct Water
//{
//  String distan;
//};
//Water sensor[2] ;

struct Meter
{
  String bat;
};

Meter meter;


const int TRIG_PIN = 22;
const int ECHO_PIN = 21;
float temp_In_C = 20.0;  // Can enter actual air temp here for maximum accuracy
float speed_Of_Sound;          // Calculated speed of sound based on air temp
float distance_Per_uSec;      // Distance sound travels in one microsecond
float distanceAVG;

void setupOTA()
{
  ArduinoOTA.setHostname(HOSTNAME.c_str());
  ArduinoOTA.setPassword(PASSWORD);
  ArduinoOTA
  .onStart([]() {
    String type;
    if (ArduinoOTA.getCommand() == U_FLASH)
      type = "sketch";
    else // U_SPIFFS
      type = "filesystem";

    // NOTE: if updating SPIFFS this would be the place to unmount SPIFFS using SPIFFS.end()
    Serial.println("Start updating " + type);
  })
  .onEnd([]() {
    Serial.println("\nEnd");
  })
  .onProgress([](unsigned int progress, unsigned int total) {
    Serial.printf("Progress: %u%%\r", (progress / (total / 100)));
  })
  .onError([](ota_error_t error) {
    Serial.printf("Error[%u]: ", error);
    if (error == OTA_AUTH_ERROR) Serial.println("Auth Failed");
    else if (error == OTA_BEGIN_ERROR) Serial.println("Begin Failed");
    else if (error == OTA_CONNECT_ERROR) Serial.println("Connect Failed");
    else if (error == OTA_RECEIVE_ERROR) Serial.println("Receive Failed");
    else if (error == OTA_END_ERROR) Serial.println("End Failed");
  });

  ArduinoOTA.begin();
}

void reconnectMqtt()
{
  if ( client.connect("Thingcontrol_AT", deviceToken.c_str(), NULL) )
  {
    Serial.println( F("Connect MQTT Success."));
    client.subscribe("v1/devices/me/rpc/request/+");
  }
  else {
    Serial.println( F("Connect MQTT Fail."));
  }
}

void setup() {
  //  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  Serial.begin(115200); // Open serial connection to report values to host


  // Formula to calculate speed of sound in meters/sec based on temp
  speed_Of_Sound = 331.1 + (0.606 * temp_In_C);
  // Calculate the distance that sound travels in one microsecond in centimeters
  distance_Per_uSec = speed_Of_Sound / 10000.0;
  deviceToken = mac2String((byte*) &espChipID);
  HOSTNAME.concat(deviceToken);
  HOSTNAME.toCharArray(WIFINAME, 50);

  Serial.println(F("Starting... Ambient Temperature/Humidity Monitor"));
  Serial.println();
  Serial.println(F("***********************************"));
  Serial.println(deviceToken);
  Serial.println(vers);
  WiFiManager wifiManager;
  wifiManager.setAPCallback(configModeCallback);


  if (!wifiManager.autoConnect (WIFINAME)) {
    Serial.println("failed to connect and hit timeout");
    delay(1000);
  }
  client.setServer( thingsboardServer, PORT );
  reconnectMqtt();

  //  SerialBT.begin(HOSTNAME); //Bluetooth device name
  //  SerialBT.println(HOSTNAME);
  setupOTA();

  Serial.print("Start.....");
  startMillis = millis();  //initial start time
  dayMillis = 0;

  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);

  starSendTeletMillis = millis() + (60 * 1000);

}

void setWiFi()
{
  Serial.println("OK");
  Serial.println("+:Reconfig WiFi  Restart...");
  WiFiManager wifiManager;
  wifiManager.resetSettings();
  if (!wifiManager.startConfigPortal("ThingControlCommand"))
  {
    Serial.println("failed to connect and hit timeout");
    delay(3000);
    delay(5000);
  }
  Serial.println("OK");
  Serial.println("+:WiFi Connect");
  client.setServer( thingsboardServer, PORT );  // secure port over TLS 1.2
  reconnectMqtt();
}

void processTele(char jsonTele[])
{
  char *aString = jsonTele;
  Serial.println("OK");
  Serial.print(F("+:topic v1/devices/me/ , "));
  Serial.println(aString);
  client.publish( "v1/devices/me/telemetry", aString);
}

void appendDistanceToBuffer(int value)
{
  DistanceBuffer[DistanceBufferIndex] = value;
  DistanceBufferIndex++;
  if (DistanceBufferIndex >= DistanceBufferLength)
    DistanceBufferIndex = 0;
}



int average(int *array, int len) // assuming array is int.
{
  long sum = 0L; // sum will be larger than an item, long for safety.
  for (int i = 0; i < len; i++)
    sum += array[i];
  return ((float)sum) / len; // average will be fractional, so float may be appropriate.
}



void read_distance()
{
  float duration, distanceCm, distanceIn, distanceFt, distanceAVG = 0;
  unsigned long start_TIME, END_TIME, MY_TIME;
  start_TIME = millis();

    digitalWrite(TRIG_PIN, HIGH);       // Set trigger pin HIGH
    delayMicroseconds(15);              // Hold pin HIGH for 20 uSec
    digitalWrite(TRIG_PIN, LOW);        // Return trigger pin back to LOW again.
    duration = pulseIn(ECHO_PIN, HIGH); // Measure time in uSec for echo to come back.

    // convert the time data into a distance in centimeters, inches and feet
    duration = duration / 2.0;  // Divide echo time by 2 to get time in one direction
    distanceCm = duration * distance_Per_uSec;
    distanceIn = distanceCm / 2.54;
    distanceFt = distanceIn / 12.0;

    if (distanceCm <= 0) {
      Serial.println("Out of range");
    }
    else {
      Serial.print(distanceCm, 0);
      Serial.println("cm,  ");
      appendDistanceToBuffer(distanceCm);
    }
  
  Serial.print("distance++ = ");
  Serial.print(distan);
  Serial.println("cm,  ");
  
  Serial.print("distan = ");
  Serial.print(distan);
  Serial.println("cm,  ");
  END_TIME = millis();
  MY_TIME = END_TIME - start_TIME;
  Serial.print("read_Sensor_TIME: ");
  Serial.print(MY_TIME);
  Serial.println(" millisec,  ");
  Serial.println(" ////////////////////////////////");
}

// Read battery function
float Read_Batt()
{
  unsigned int vRAW = 0;
  float Vout = 0.0;
  float Vin = 0.0;
  float R1 = 15000.0;
  float R2 = 3300.0;
  int bitRes = 4096;
  int16_t adc = 0;
  //Serial.println("Read_Batt()");
  for (int a = 0; a < 20; a++)
  {
    adc  += analogRead(battPIN);
    Serial.print(adc);
    delay(1);
  }

  vRAW = adc / 20;
  Vout = (vRAW * 3.3) / bitRes;
  Vin = Vout / (R2 / (R1 + R2));
  if (Vin < 0.05)
  {
    Vin = 0.0;
  }
  //Serial.println("end.Read_Batt()");
  return Vin;
}


void sendtelemetry()
{
  String json = "";
  json.concat("{\"D\":");
  json.concat(distan);
  json.concat(",\"bat\":");
  json.concat(meter.bat);
  json.concat(",\"Ver\":");
  json.concat(FirmwareVer);
  json.concat("}");
  Serial.println(json);
  client.publish( "v1/devices/me/telemetry",  json.c_str());
}

void doneProcess()
{
  Serial.println("!!!!!! Done ready to Sleep ~10 Min (TPL5110) !!!!!!");
  pinMode(donePIN, OUTPUT);
  digitalWrite(donePIN, HIGH);
  delay(100);
}

void loop()
{
  status = WiFi.status();
  currentMillis = millis();  //get the current "time" (actually the number of milliseconds since the program started)

  if ( status == WL_CONNECTED)
  {
    if ( !client.connected() )
    {
      reconnectMqtt();
    }
    setupOTA();
  }

  if (currentMillis - ReadDistance_TIME >= periodReadDistance_TIME) 
  {
    read_distance();
    ReadDistance_TIME = currentMillis;  
  }

  //send
  if (currentMillis - starSendTeletMillis >= periodSendTelemetry)  //test whether the period has elapsed
  {
    getLocalTime(&timeinfo);
    meter.bat = Read_Batt();
    distan = average(DistanceBuffer,DistanceBufferLength);
    sendtelemetry();
     OTA_git_CALL();
    if ((timeinfo.tm_hour >= 0  && timeinfo.tm_hour < 5) || (timeinfo.tm_hour >= 21)) {
      doneProcess();
    }
    starSendTeletMillis = currentMillis;  //IMPORTANT to save the start time of the current LED state.
  }
  ArduinoOTA.handle();
  client.loop();
}

