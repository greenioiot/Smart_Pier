#include <Arduino.h>

/*
#include "BluetoothSerial.h"
#if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
#error Bluetooth is not enabled! Please run `make menuconfig` to and enable it
#endif
*/
#include <ArduinoJson.h>

#include <EEPROM.h>
#include <ArduinoOTA.h>
#include <WiFi.h>
#include <Wire.h>
#include <ModbusMaster.h>
#include "DOSensor.h"
#include <HardwareSerial.h>
#include "HardwareSerial_NB_BC95.h"
#include <TaskScheduler.h>

#include <WiFiManager.h>
#include "WiFiClientSecure.h"
#include <HTTPClient.h>
#include <HTTPUpdate.h>
#include "cert.h"
#include <Update.h>

#define _TASK_TIMECRITICAL

HardwareSerial modbus(2);
HardwareSerial_NB_BC95 AISnb;

//BluetoothSerial SerialBT;


String FirmwareVer = "0.1";

#define URL_fw_Version "https://raw.githubusercontent.com/greenioiot/Smart_Pier/main/SET1_BGT485W818_LowPower/bin_version.txt"

#define URL_fw_Bin "https://raw.githubusercontent.com/greenioiot/Smart_Pier/main/SET1_BGT485W818_LowPower/firmware.bin"


#define battPIN  34
#define donePIN  25

const char* ssid = "greenio"; //replace "xxxxxx" with your WIFI's ssid
const char* password = "green7650"; //replace "xxxxxx" with your WIFI's password

String HOSTNAME = "";
String deviceToken = "";
String serverIP = "147.50.151.130"; // Your Server IP;
String serverPort = "19956"; // Your Server Port;
String json = "";

ModbusMaster node;

#define trigWDTPin    32
#define ledHeartPIN   0

#define raingaugePIN   4

boolean raingaugeSTA ;

struct Meter
{
  String SO2;
  String NO2;
  String CO;
  String O3;
  String PM2_5;
  String PM10;
  String temp;
  String hum;

  float bat;

};
Meter meter;
Signal meta;
uint16_t dataWeather[8];

unsigned long currentMillis;
unsigned long previousMillis, previousSetwifi;
int interval = 60, intervalSetwifi = 90; // Interval Time
int intervalSleep = 30; // Interval Time
//unsigned int previous_check = 0;
boolean waitSleep = 0;
unsigned long previousMillisSleep;


int interval2 = 20 ;
unsigned long previous2;

float Batt = 0.0;
int countSend = 0;

WiFiManager wifiManager;

uint64_t espChipID = ESP.getEfuseMac();

String mac2String(byte ar[]) {
  String s;
  for (byte i = 0; i < 6; ++i)
  {
    char buf[3];
    sprintf(buf, "%02X", ar[i]); // J-M-L: slight modification, added the 0 in the format for padding
    s += buf;
    if (i < 5) s += ':';
  }
  return s;
}


void firmwareUpdate();

int FirmwareVersionCheck(void)
{
  String payload;
  int httpCode;
  String fwurl = "";
  fwurl += URL_fw_Version;
  fwurl += "?";
  fwurl += String(rand());
  Serial.println(fwurl);
  WiFiClientSecure *client = new WiFiClientSecure;

  if (client)
  {
    client->setCACert(rootCACertificate);

    // Add a scoping block for HTTPClient https to make sure it is destroyed before WiFiClientSecure *client is
    HTTPClient https;

    if (https.begin(*client, fwurl))
    { // HTTPS
      Serial.print("[HTTPS] GET...\n");
      // start connection and send HTTP header
      delay(100);
      httpCode = https.GET();
      delay(100);
      if (httpCode == HTTP_CODE_OK) // if version received
      {
        payload = https.getString(); // save received version
      }
      else
      {
        Serial.print("error in downloading version file:");
        Serial.println(httpCode);
      }
      https.end();
    }
    delete client;
  }

  if (httpCode == HTTP_CODE_OK) // if version received
  {
    payload.trim();
    if (payload.equals(FirmwareVer))
    {
      Serial.printf("\nDevice already on latest firmware version:%s\n", FirmwareVer);
      return 0;
    }
    else
    {
      Serial.println(payload);
      Serial.println("New firmware detected");
      return 1;
    }
  }
  return 0;
}

void firmwareUpdate(void)
{
  WiFiClientSecure client;
  client.setCACert(rootCACertificate);
  t_httpUpdate_return ret = httpUpdate.update(client, URL_fw_Bin);

  switch (ret)
  {
  case HTTP_UPDATE_FAILED:
    Serial.printf("HTTP_UPDATE_FAILD Error (%d): %s\n", httpUpdate.getLastError(), httpUpdate.getLastErrorString().c_str());
    break;

  case HTTP_UPDATE_NO_UPDATES:
    Serial.println("HTTP_UPDATE_NO_UPDATES");
    break;

  case HTTP_UPDATE_OK:
    Serial.println("HTTP_UPDATE_OK");
    break;
  }
}

void OTA_git_CALL()
{
  if (FirmwareVersionCheck())
  {
    firmwareUpdate();
  }
}

void configModeCallback (WiFiManager *myWiFiManager) {
  Serial.println("Entered config mode");
  Serial.println(WiFi.softAPIP());
  //if you used auto generated SSID, print it
  Serial.println(myWiFiManager->getConfigPortalSSID());
}


void setupWIFI()
{
  WiFi.setHostname(HOSTNAME.c_str());
  byte count = 0;
  while (WiFi.status() != WL_CONNECTED && count < 10)
  {
    count ++;
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED)
    Serial.println("Connecting...OK.");
  else
    Serial.println("Connecting...Failed");
}

void setupOTA()
{
  ArduinoOTA.setHostname(HOSTNAME.c_str());
  ArduinoOTA.setPassword(password);
  ArduinoOTA.onStart([]() {
    String type;
    if (ArduinoOTA.getCommand() == U_FLASH)
      type = "sketch";
    else // U_SPIFFS
      type = "filesystem";

    // NOTE: if updating SPIFFS this would be the place to unmount SPIFFS using SPIFFS.end()
    Serial.println("Start updating " + type);
  })
  .onEnd([]() {
    Serial.println("Update Complete!");
    //SerialBT.println("Update Complete!");
  })
  .onProgress([](unsigned int progress, unsigned int total) {
    Serial.printf("Progress: %u%%\r", (progress / (total / 100)));
    //SerialBT.printf("Progress: %u%%\n", (progress / (total / 100)));

  })
  .onError([](ota_error_t error) {
    Serial.printf("Error[%u]: ", error);
    if (error == OTA_AUTH_ERROR) Serial.println("Auth Failed");
    else if (error == OTA_BEGIN_ERROR) Serial.println("Begin Failed");
    else if (error == OTA_CONNECT_ERROR) Serial.println("Connect Failed");
    else if (error == OTA_RECEIVE_ERROR) Serial.println("Receive Failed");
    else if (error == OTA_END_ERROR) Serial.println("End Failed");
  });

  ArduinoOTA.begin();
}

void setup()
{
  Serial.begin(115200);
  modbus.begin(9600, SERIAL_8N1, 16, 17);

   HOSTNAME = mac2String((byte*) &espChipID);
Serial.println(HOSTNAME);
  AISnb.debug = true;
  AISnb.setupDevice(serverPort);
  deviceToken = AISnb.getNCCID();


 
  
  wifiManager.setTimeout(60);
  wifiManager.setAPCallback(configModeCallback);
   if (!wifiManager.autoConnect(HOSTNAME.c_str())) {
    //Serial.println("failed to connect and hit timeout");
    //reset and try again, or maybe put it to deep sleep
    //    ESP.reset();
    //delay(1000);
  }

  
  //SerialBT.begin(HOSTNAME); //Bluetooth device name
  //SerialBT.println(HOSTNAME);
  Serial.print("nccid:");
  Serial.println(deviceToken);
  Serial.println();
  Serial.println(F("***********************************"));
  Serial.println("Initialize...");
  pinMode(raingaugePIN, INPUT_PULLUP);
  raingaugeSTA = digitalRead(raingaugePIN);
  setupWIFI();
  setupOTA();
}

void sendViaNBIOT()
{
   meta = AISnb.getSignal();
  Serial.print("RSSI:"); Serial.println(meta.rssi);

json = "";
  json.concat("{\"Tn\":\"");
  json.concat(deviceToken);
  json.concat("\",\"SO2\":");
  json.concat(meter.SO2);
  json.concat(",\"NO2\":");
  json.concat(meter.NO2);
  json.concat(",\"CO\":");
  json.concat(meter.CO);
  json.concat(",\"O3\":");
  json.concat(meter.O3);
  json.concat(",\"PM2_5\":");
  json.concat(meter.PM2_5);
  json.concat(",\"PM10\":");
  json.concat(meter.PM10);
  json.concat(",\"temp\":");
  json.concat(meter.temp);
  json.concat(",\"hum\":");
  json.concat(meter.hum);
  json.concat(",\"bat\":");
  json.concat(meter.bat);
  json.concat(",\"rssi\":");
  json.concat(meta.rssi);
  json.concat(",\"csq\":");
  json.concat(meta.csq);
  json.concat(",\"ver\":");
  json.concat(FirmwareVer);
  json.concat("}");
  Serial.println(json);

  //SerialBT.println(json);

  UDPSend udp = AISnb.sendUDPmsgStr(serverIP, serverPort, json);
  UDPReceive resp = AISnb.waitResponse();
  Serial.print("rssi:");
  Serial.println(meta.rssi);
  //SerialBT.print("rssi:");
  //SerialBT.println(meta.rssi);
}

float Read_Batt()
{
  unsigned int vRAW = 0;
  float Vout = 0.0;
  float Vin = 0.0;
  float R1 = 15000.0;
  float R2 = 3300.0;
  int bitRes = 4096;
  int16_t adc = 0;
  Serial.println("Read_Batt()");
  for (int a = 0; a < 20; a++)
  {
    adc  += analogRead(battPIN);
    Serial.print(adc);
    delay(1);
  }
  vRAW = adc / 20;
  Vout = (vRAW * 3.3) / bitRes;
  Vin = Vout / (R2 / (R1 + R2));
  if (Vin < 0.05)
  {
    Vin = 0.0;
  }
  Serial.println("end.Read_Batt()");
  return Vin;
}

void readWeather(uint16_t  REG)
{
  static uint32_t i;
  uint16_t j, result;
  uint32_t value = 0;
  float val = 0.1;

  // communicate with Modbus slave ID 1 over Serial (port 2)
  node.begin(ID_Meter, modbus);

  // slave: read (6) 16-bit registers starting at register 2 to RX buffer
  result = node.readHoldingRegisters(REG, 8);
  Serial.print("result:"); Serial.print(result); Serial.print(" node.ku8MBSuccess:"); Serial.println(node.ku8MBSuccess);

  // do something with data if read is successful
  if (result == node.ku8MBSuccess)
  {
    for (j = 0; j < 8; j++)
    {
      dataWeather[j] = node.getResponseBuffer(j);
      //SerialBT.print(REG); SerialBT.print(":"); SerialBT.print(j); SerialBT.print(":");  SerialBT.println(dataWeather[j]);
      //Serial.print(REG); Serial.print(":"); Serial.print(j); Serial.print(":");  Serial.println(dataWeather[j]);
    }
    meter.SO2 = dataWeather[0];
    meter.NO2 = dataWeather[1];
    meter.CO = dataWeather[2];
    meter.O3 = dataWeather[3];
    meter.PM2_5 = dataWeather[4];
    meter.PM10 = dataWeather[5];
    meter.temp = dataWeather[6] / 100 - 40;
    meter.hum = dataWeather[7] / 100;

  } else {
    Serial.print("Connec modbus fail. REG >>> "); Serial.println(REG, HEX); // Debug
  }
}

void readMeter()
{
  readWeather(_SO2);
}

void doneProcess()
{
  Serial.println("!!!!!! Done ready to Sleep ~10 Min (TPL5110) !!!!!!");
  pinMode(donePIN, OUTPUT);
  digitalWrite(donePIN, HIGH);
  delay(100);


}

//********************************************************************//
//*********************** HeartBeat Function **************************//
//********************************************************************//
void HeartBeat() {
  //   Sink current to drain charge from watchdog circuit
  pinMode(trigWDTPin, OUTPUT);
  digitalWrite(trigWDTPin, LOW);
  // Led monitor for Heartbeat
  digitalWrite(ledHeartPIN, LOW);
  delay(300);
  digitalWrite(ledHeartPIN, HIGH);
  // Return to high-Z
  pinMode(trigWDTPin, INPUT);
  Serial.println("Heartbeat");
}

void t1CallgetMeter() {     // Update read all data
  readMeter();
  meter.bat = Read_Batt();
  sendViaNBIOT();
}

void t2Callget_raingauge() {     // Update read all data
  if (digitalRead(raingaugePIN) != raingaugeSTA) {
    raingaugeSTA = !raingaugeSTA ;
    Serial.println(raingaugeSTA);
    json = "";
    json.concat("{\"Tn\":\"");
    json.concat(deviceToken);
    json.concat("\",\"Rain\":");
    json.concat(raingaugeSTA);
    json.concat("}");
    Serial.println(json);
    //SerialBT.println(json);
    //
    UDPSend udp = AISnb.sendUDPmsgStr(serverIP, serverPort, json);
  }

}

void loop()
{
  currentMillis = millis() / 1000;
  t2Callget_raingauge();

  if (currentMillis - previousSetwifi >= intervalSetwifi)
  {
    Serial.println("Attach WiFi for，OTA "); Serial.println(WiFi.RSSI() );
    setupWIFI();
    HeartBeat();
    setupOTA();
    previousSetwifi = currentMillis ;
  }

  if (currentMillis - previous2 >= interval2)
  {
    //SerialBT.println("VER:" + Ver);
    Serial.println("VER:" + FirmwareVer);
    previous2 = currentMillis ;
  }

  if ((currentMillis - previousMillis >= interval))
  {
    t1CallgetMeter();
    OTA_git_CALL();
    previousMillis = currentMillis ;
    countSend++;
    Serial.println("countSend:" + String(countSend));
    //SerialBT.println("countSend:" + String(countSend));
    if (countSend >= 6)
    {
      delay(1000);
      doneProcess();
    }
  }
  
  ArduinoOTA.handle();
}
